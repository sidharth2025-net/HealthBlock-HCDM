# HealthBlock - Updated (based on your uploaded reference)

## Overview
Simplified, maintainable demo of a healthcare EHR management system.
- Modernized frontend design (backgrounds, cards, responsive layout).
- Backend: Node/Express + SQLite (files stored under `data/`).
- Lab assistant can hide records; doctors see only non-hidden records.
- Patient uploads stored in `data/` and served at `/uploads`.

## Run in GitHub Codespaces
1. Open the project in Codespaces (or any environment with Node.js >=16).
2. In terminal:
   ```bash
   npm install
   npm start
   ```
3. Forward port `4000` in Codespaces port preview (or open http://localhost:4000 locally).
4. Open `/patient.html`, `/doctor.html`, `/lab.html` pages in the browser.

## Notes
- To enable IPFS pinning, modify the upload endpoint in `backend/index.js` to call a pinning service and store CID.
- For production, add authentication and secure file storage (S3, IPFS, or encrypted store).
