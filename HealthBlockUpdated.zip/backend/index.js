const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { nanoid } = require('nanoid');
const Database = require('better-sqlite3');
const app = express();
app.use(cors());
app.use(bodyParser.json());
const uploadDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
app.use('/uploads', express.static(uploadDir));
const db = new Database(path.join(__dirname, '..', 'healthblock.db'));
db.prepare(`CREATE TABLE IF NOT EXISTS doctors (id TEXT PRIMARY KEY, name TEXT, phone TEXT, email TEXT, live INTEGER DEFAULT 1)`).run();
db.prepare(`CREATE TABLE IF NOT EXISTS patients (id TEXT PRIMARY KEY, fullname TEXT, email TEXT, phone TEXT, address TEXT, patient_record_id TEXT)`).run();
db.prepare(`CREATE TABLE IF NOT EXISTS prescriptions (id TEXT PRIMARY KEY, patient_id TEXT, doctor_id TEXT, filename TEXT, filepath TEXT, created_at TEXT, hidden INTEGER DEFAULT 0)`).run();
const storage = multer.diskStorage({ destination: (req, file, cb)=>cb(null, uploadDir), filename: (req,file,cb)=>cb(null, Date.now()+'-'+file.originalname)});
const upload = multer({ storage });
// Seed doctors
if (db.prepare('SELECT COUNT(*) as c FROM doctors').get().c === 0){
  const docs = [{id:'doc1',name:'Dr. Asha Rao',phone:'+91-9000000001',email:'asha@example.com'},{id:'doc2',name:'Dr. Vikram Sen',phone:'+91-9000000002',email:'vikram@example.com'},{id:'doc3',name:'Dr. Meera Iyer',phone:'+91-9000000003',email:'meera@example.com'}];
  const ins = db.prepare('INSERT INTO doctors (id,name,phone,email,live) VALUES (?,?,?,?,1)');
  const t = db.transaction((arr)=>{ for(const d of arr) ins.run(d.id,d.name,d.phone,d.email); });
  t(docs);
}
app.post('/api/register/doctor', (req,res)=>{ try{ const {name,phone,email}=req.body; const id=nanoid(8); db.prepare('INSERT INTO doctors (id,name,phone,email,live) VALUES (?,?,?,?,1)').run(id,name,phone,email); res.json({ok:true,id}); }catch(e){res.status(500).json({ok:false,error:e.message})}});
app.get('/api/doctors',(req,res)=>{ res.json(db.prepare('SELECT id,name,phone,email,live FROM doctors WHERE live=1').all()); });
app.post('/api/register/patient',(req,res)=>{ try{ const {fullname,email,phone,address}=req.body; const id=nanoid(8); const prid='PB-'+Date.now().toString().slice(-6); db.prepare('INSERT INTO patients (id,fullname,email,phone,address,patient_record_id) VALUES (?,?,?,?,?,?)').run(id,fullname,email,phone,address,prid); res.json({ok:true,id,patient_record_id:prid}); }catch(e){res.status(500).json({ok:false,error:e.message})}});
app.post('/api/patients/:patientId/upload', upload.single('file'), (req,res)=>{ try{ const patientId=req.params.patientId; if(!req.file) return res.status(400).json({ok:false,error:'no file'}); const id=nanoid(10); const created_at=new Date().toISOString(); db.prepare('INSERT INTO prescriptions (id,patient_id,doctor_id,filename,filepath,created_at,hidden) VALUES (?,?,?,?,?,?,0)').run(id,patientId,req.body.doctor_id||null,req.file.originalname,req.file.filename,created_at); res.json({ok:true,id,filename:req.file.filename,url:'/uploads/'+req.file.filename}); }catch(e){res.status(500).json({ok:false,error:e.message})}});
app.get('/api/doctor/:doctorId/records',(req,res)=>{ const doctorId=req.params.doctorId; const rows = db.prepare('SELECT p.id,p.patient_id,p.doctor_id,p.filename,p.filepath,p.created_at,p.hidden,pt.fullname,pt.patient_record_id FROM prescriptions p LEFT JOIN patients pt ON p.patient_id = pt.id WHERE (p.doctor_id = ? OR p.doctor_id IS NULL) AND p.hidden=0 ORDER BY p.created_at DESC').all(doctorId); res.json(rows); });
app.get('/api/lab/records',(req,res)=>{ const rows=db.prepare('SELECT p.id,p.patient_id,p.doctor_id,p.filename,p.filepath,p.created_at,p.hidden,pt.fullname,pt.patient_record_id FROM prescriptions p LEFT JOIN patients pt ON p.patient_id = pt.id ORDER BY p.created_at DESC').all(); res.json(rows); });
app.post('/api/lab/records/:id/toggle', (req,res)=>{ try{ const id=req.params.id; const r=db.prepare('SELECT hidden FROM prescriptions WHERE id = ?').get(id); if(!r) return res.status(404).json({ok:false,error:'not found'}); const newv = r.hidden ? 0 : 1; db.prepare('UPDATE prescriptions SET hidden=? WHERE id=?').run(newv,id); res.json({ok:true,id,hidden:newv}); }catch(e){res.status(500).json({ok:false,error:e.message})}});
app.get('/api/patients/:id',(req,res)=>{ const id=req.params.id; const row = db.prepare('SELECT id,fullname,email,phone,address,patient_record_id FROM patients WHERE id = ?').get(id); if(!row) return res.status(404).json({ok:false,error:'not found'}); res.json(row); });
app.get('/api/patients',(req,res)=>{ const rows = db.prepare('SELECT id,fullname,email,phone,address,patient_record_id FROM patients ORDER BY fullname LIMIT 200').all(); res.json(rows); });
app.use('/', express.static(path.join(__dirname, '..', 'frontend')));
const port = process.env.PORT || 4000; app.listen(port, ()=>console.log('HealthBlock server running on port', port));
