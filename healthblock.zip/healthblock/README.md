# HealthBlock - Demo Healthcare Data Management System

## Overview
This is a simple full-stack demo (backend: Node/Express + SQLite; frontend: static pages) that demonstrates:
- Doctor registration and listing (3 sample doctors seeded)
- Patient registration (Full Name, Email, Phone, Address, generated Patient Record ID)
- Patient uploads report/prescription (file stored in `data/` and record in SQLite)
- Lab assistant can view all uploads and toggle hide/show (hides from doctor view)
- Doctor view shows live records (non-hidden)

**Note:** For a production IPFS integration, you can implement an IPFS pinning solution (Infura / Pinata) and call their API from the upload endpoint. This project saves files locally in `data/` for simplicity.

## Files & structure
- `backend/` - Node/Express server (main file: `backend/index.js`)
- `frontend/` - Static HTML pages (patient.html, doctor.html, lab.html)
- `healthblock.db` - SQLite database (created on first run)
- `data/` - Uploaded files directory (served at `/uploads`)
- `package.json` - Node dependencies and start scripts

## Run in GitHub Codespaces (or locally)
1. Open the project in Codespaces (or any machine with Node.js >=16).
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the server:
   ```bash
   npm start
   ```
   Or during development:
   ```bash
   npm run dev
   ```
4. Open `http://localhost:4000` in the Codespaces forwarded port preview (port 4000).

## Usage
- Patient Portal: `/patient.html` — register a patient then upload files.
- Doctor Portal: `/doctor.html` — register doctors and view live (non-hidden) records.
- Lab Assistant: `/lab.html` — view all uploads and toggle hide/show.

## Extending to IPFS (notes)
- After upload, you can pin the file to IPFS by calling a pinning service (Pinata/Infura) with the file path.
- Save returned IPFS CID in `prescriptions` table (add a column) to reference IPFS-stored records.

## Deliverable
A zip file `healthblock.zip` is included in the project root. Unzip and run as above.
