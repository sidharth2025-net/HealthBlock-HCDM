const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { nanoid } = require('nanoid');
const Database = require('better-sqlite3');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use('/uploads', express.static(path.join(__dirname, '..', 'data')));
const port = process.env.PORT || 4000;

// Setup storage for uploaded files (EHR)
const uploadDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

// Simple SQLite DB using better-sqlite3
const dbPath = path.join(__dirname, '..', 'healthblock.db');
const db = new Database(dbPath);
// initialize tables
db.prepare(`CREATE TABLE IF NOT EXISTS doctors (
  id TEXT PRIMARY KEY, name TEXT, phone TEXT, email TEXT, live INTEGER DEFAULT 1
)`).run();
db.prepare(`CREATE TABLE IF NOT EXISTS patients (
  id TEXT PRIMARY KEY, fullname TEXT, email TEXT, phone TEXT, address TEXT, patient_record_id TEXT
)`).run();
db.prepare(`CREATE TABLE IF NOT EXISTS prescriptions (
  id TEXT PRIMARY KEY, patient_id TEXT, doctor_id TEXT, filename TEXT, filepath TEXT, created_at TEXT, hidden INTEGER DEFAULT 0
)`).run();
db.prepare(`CREATE TABLE IF NOT EXISTS lab_access (
  id TEXT PRIMARY KEY, lab_name TEXT, can_view INTEGER DEFAULT 1
)`).run();

// Seed sample doctors (3-5)
const seedDoctors = db.prepare('SELECT COUNT(*) as c FROM doctors').get().c === 0;
if (seedDoctors) {
  const docs = [
    { id: 'doc1', name: 'Dr. Asha Rao', phone: '+91-9000000001', email: 'asha@example.com' },
    { id: 'doc2', name: 'Dr. Vikram Sen', phone: '+91-9000000002', email: 'vikram@example.com' },
    { id: 'doc3', name: 'Dr. Meera Iyer', phone: '+91-9000000003', email: 'meera@example.com' }
  ];
  const insert = db.prepare('INSERT INTO doctors (id,name,phone,email,live) VALUES (?,?,?,?,1)');
  const insertMany = db.transaction((arr) => {
    for (const d of arr) insert.run(d.id, d.name, d.phone, d.email);
  });
  insertMany(docs);
}

// Routes

// Register doctor
app.post('/api/register/doctor', (req, res) => {
  try {
    const { name, phone, email } = req.body;
    const id = nanoid(8);
    db.prepare('INSERT INTO doctors (id,name,phone,email,live) VALUES (?,?,?,?,1)').run(id, name, phone, email);
    res.json({ ok: true, id });
  } catch (e) { console.error(e); res.status(500).json({ ok:false, error: e.message }); }
});

// List doctors (live)
app.get('/api/doctors', (req, res) => {
  const rows = db.prepare('SELECT id,name,phone,email,live FROM doctors WHERE live=1').all();
  res.json(rows);
});

// Register patient
app.post('/api/register/patient', (req, res) => {
  try {
    const { fullname, email, phone, address } = req.body;
    const id = nanoid(8);
    const patientRecordId = 'PB-' + Date.now().toString().slice(-6);
    db.prepare('INSERT INTO patients (id,fullname,email,phone,address,patient_record_id) VALUES (?,?,?,?,?,?)')
      .run(id, fullname, email, phone, address, patientRecordId);
    res.json({ ok:true, id, patient_record_id: patientRecordId });
  } catch (e) { console.error(e); res.status(500).json({ ok:false, error: e.message }); }
});

// Upload patient report / prescription (patient uploads for doctor)
app.post('/api/patients/:patientId/upload', upload.single('file'), (req, res) => {
  try {
    const patientId = req.params.patientId;
    const { doctor_id } = req.body;
    if (!req.file) return res.status(400).json({ ok:false, error: 'no file' });
    const id = nanoid(10);
    const created_at = new Date().toISOString();
    db.prepare('INSERT INTO prescriptions (id,patient_id,doctor_id,filename,filepath,created_at,hidden) VALUES (?,?,?,?,?,?,0)')
      .run(id, patientId, doctor_id||null, req.file.originalname, req.file.filename, created_at);
    res.json({ ok:true, id, filename: req.file.filename, url: '/uploads/' + req.file.filename });
  } catch (e) { console.error(e); res.status(500).json({ ok:false, error: e.message }); }
});

// Doctor view records (live records, only not hidden)
app.get('/api/doctor/:doctorId/records', (req, res) => {
  const doctorId = req.params.doctorId;
  const rows = db.prepare('SELECT p.id,p.patient_id,p.doctor_id,p.filename,p.filepath,p.created_at,p.hidden,pt.fullname,pt.patient_record_id FROM prescriptions p LEFT JOIN patients pt ON p.patient_id = pt.id WHERE (p.doctor_id = ? OR p.doctor_id IS NULL) AND p.hidden=0 ORDER BY p.created_at DESC').all(doctorId);
  res.json(rows);
});

// Lab assistant: list all records (lab can hide/show)
app.get('/api/lab/records', (req, res) => {
  const rows = db.prepare('SELECT p.id,p.patient_id,p.doctor_id,p.filename,p.filepath,p.created_at,p.hidden,pt.fullname,pt.patient_record_id FROM prescriptions p LEFT JOIN patients pt ON p.patient_id = pt.id ORDER BY p.created_at DESC').all();
  res.json(rows);
});

// Lab toggles hide/show a record
app.post('/api/lab/records/:id/toggle', (req, res) => {
  try {
    const id = req.params.id;
    const r = db.prepare('SELECT hidden FROM prescriptions WHERE id = ?').get(id);
    if (!r) return res.status(404).json({ ok:false, error: 'not found' });
    const newv = r.hidden ? 0 : 1;
    db.prepare('UPDATE prescriptions SET hidden=? WHERE id=?').run(newv, id);
    res.json({ ok:true, id, hidden: newv });
  } catch (e) { res.status(500).json({ ok:false, error: e.message }); }
});

// Get patient details
app.get('/api/patients/:id', (req, res) => {
  const id = req.params.id;
  const row = db.prepare('SELECT id,fullname,email,phone,address,patient_record_id FROM patients WHERE id = ?').get(id);
  if (!row) return res.status(404).json({ ok:false, error: 'not found' });
  res.json(row);
});

// Simple search of patients
app.get('/api/patients', (req, res) => {
  const rows = db.prepare('SELECT id,fullname,email,phone,address,patient_record_id FROM patients ORDER BY fullname LIMIT 200').all();
  res.json(rows);
});

// Serve frontend static files
app.use('/', express.static(path.join(__dirname, '..', 'frontend')));

app.listen(port, () => console.log('HealthBlock server running on port', port));
